<footer class="page-footer">
        <div class="row">
            <div class="container">
                <p class="text-center">

                Developed by <a href="https://www.fiverr.com/users/wordpress_slick/seller_dashboard">Mink Strings</a>
                </p>
            </div>
        </div>
    </footer>
